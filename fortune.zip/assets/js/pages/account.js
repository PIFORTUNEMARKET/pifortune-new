if (!localStorage.getItem("user")) {
  window.location.href = "/";
}
